# coding: utf-8
import boto3
import re
import requests
from requests_aws4auth import AWS4Auth
from pprint import pprint
from elasticsearch import Elasticsearch, RequestsHttpConnection, helpers
import shlex
import gzip
import io
import os
import fnmatch

session = boto3.Session(profile_name = 'corpnew')

region = 'us-east-1' # e.g. us-west-1
service = 'es'
AccessKeyId = 'AKIAJXBP4EXIXMKW5EWA'
SecretAccessKey = '17v+ILjvl7//se6CAgwJBa5ERSw05YdhWmb0+EToQ'
awsauth = AWS4Auth(AccessKeyId, SecretAccessKey, region, service)
hosts = ["elastic-1.ardentmc.com", "elastic-2.ardentmc.com", "elastic-3.ardentmc.com"]
index_names = ["elb-log-index", "vpc-log-index"]
elb_type_name = "elb-log-type"
vpc_type_name = "vpc-log-type"

headers = { "Content-Type": "application/json" }

s3 = boto3.client('s3')
s3Resource = boto3.resource('s3')
bucket = 'ardentmc-dev-djs-multi-logs'
key = '950417325420_elasticloadbalancing_us-east-1_app.Ardent-ELB.538678ba671ce590_20181112T1455Z_10.100.11.80_13gmvsq6.log.gz'
object = s3Resource.Object('ardentmc-dev-djs-multi-logs','950417325420_elasticloadbalancing_us-east-1_app.Ardent-ELB.538678ba671ce590_20181112T1455Z_10.100.11.80_13gmvsq6.log.gz')

es = Elasticsearch(
    hosts=hosts,
    http_auth=awsauth,
    use_ssl=False,
    verify_certs=True,
    connection_class=RequestsHttpConnection
)
print(es.info())
# Regular expressions used to parse some simple log lines
ip_pattern = re.compile('(\d+\.\d+\.\d+\.\d+)')
#time_pattern = re.compile('\[(\d+\/\w\w\w\/\d\d\d\d:\d\d:\d\d:\d\d\s-\d\d\d\d)\]')
#iso8601 time_pattern
time_pattern = re.compile(r'^(-?(?:[1-9][0-9]*)?[0-9]{4})-(1[0-2]|0[1-9])-(3[01]|0[1-9]|[12][0-9])T(2[0-3]|[01][0-9]):([0-5][0-9]):([0-5][0-9])(\.[0-9]+)?(Z|[+-](?:2[0-3]|[01][0-9]):[0-5][0-9])?$')
message_pattern = re.compile('\"(.+)\"')
